/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      fontFamily: {
        sans: ['Cairo', 'system-ui', 'sans-serif'],
        quran: ['"KFGQPC Uthmanic"', 'Amiri', 'serif'],
        amiri: ['Amiri', 'serif']
      }
    }
  },
  plugins: [require('@tailwindcss/typography')]
};